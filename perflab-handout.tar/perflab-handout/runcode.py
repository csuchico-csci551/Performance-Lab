#!/usr/bin/python3

import sys,os,subprocess
from subprocess import Popen,PIPE
import random


current_dir = os.path.dirname(os.path.abspath(__file__))
# randomize the range to distribute which machines we look for open ones on
lis = list(range(31))
random.shuffle(lis)
# print(lis)

for n in lis:
    server = "o244-"+'{num:02d}'.format(num=n+1)
    a="ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no "+server+ " \"who | wc \""
    b=Popen(a, shell=True, stdout=PIPE, stderr=PIPE)
    b.wait()
    c = b.stdout.read()
    num_users = int(c.split()[0])
    if num_users > 0:
        # ignore lab machines with other users on them
        continue
    print(server)
    a="ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no "+server+ " \"cd "+ current_dir+ " && ./driver \""
    b=Popen(a, shell=True, stdout=PIPE, stderr=PIPE)
    b.wait()
    c = b.stdout.read().decode("utf-8")
    c = c.split()
    rotate_found = False
    smooth_found = False
    rotate = 0.0
    smooth = 0.0
    for line in c:
        if "Rotate:" in line:
            rotate_found=True
            continue
        if rotate_found:
            if not "Version" in line:
                rotate=float(line)
                print("Best Score Rotate: %.2f" % rotate)
            rotate_found=False
        if "Smooth:" in line:
            smooth_found=True
            continue
        if smooth_found:
            if not "Version" in line:
                smooth = float(line)
                print("Best Score Smooth: %.2f" % smooth)
            smooth_found=False
    r_score=0.0
    s_score=0.0
    if rotate > 1.1:
        r_score = 21.428571428571*rotate
    if smooth > 1.1:
        s_score = 16.666666666667*smooth
    total = r_score+s_score
    if total > 100:
        print("Grade = 110")
    else:
        print("Grade = %.2f" % total)
    quit()
